class CustomNavbar extends HTMLElement {
    connectedCallback() {
        this.attachShadow({ mode: 'open' });
        this.shadowRoot.innerHTML = `
            <style>
                nav {
                    background-color: rgba(17, 24, 39, 0.8);
                    backdrop-filter: blur(8px);
                }
                .nav-link:hover {
                    color: #6366f1;
                }
                .mobile-menu {
                    transition: all 0.3s ease;
                }
            </style>
            <nav class="fixed w-full z-50 border-b border-gray-800">
                <div class="container mx-auto px-4">
                    <div class="flex justify-between items-center py-4">
                        <a href="/" class="flex items-center space-x-2">
                            <i data-feather="zap" class="text-primary-500 w-6 h-6"></i>
                            <span class="text-xl font-bold">SpeedyBites</span>
                        </a>
                        <div class="hidden md:flex items-center space-x-6">
                            <a href="#" class="nav-link text-gray-300 hover:text-primary-500 transition">Home</a>
                            <a href="#" class="nav-link text-gray-300 hover:text-primary-500 transition">Restaurants</a>
                            <a href="#" class="nav-link text-gray-300 hover:text-primary-500 transition">Deals</a>
                            <a href="#" class="nav-link text-gray-300 hover:text-primary-500 transition">About</a>
                            <a href="#" class="bg-primary-500 hover:bg-primary-600 text-white px-4 py-2 rounded-lg font-medium transition">Sign In</a>
                        </div>
<button id="mobileMenuButton" class="md:hidden text-gray-300 focus:outline-none">
                            <i data-feather="menu" class="w-6 h-6"></i>
                        </button>
                    </div>
                    
                    <!-- Mobile menu -->
                    <div id="mobileMenu" class="mobile-menu hidden md:hidden pb-4">
                        <a href="#" class="block py-2 text-gray-300 hover:text-primary-500 transition">Home</a>
                        <a href="#" class="block py-2 text-gray-300 hover:text-primary-500 transition">Restaurants</a>
                        <a href="#" class="block py-2 text-gray-300 hover:text-primary-500 transition">Deals</a>
                        <a href="#" class="block py-2 text-gray-300 hover:text-primary-500 transition">About</a>
                        <a href="#" class="inline-block mt-2 bg-primary-500 hover:bg-primary-600 text-white px-4 py-2 rounded-lg font-medium transition">Sign In</a>
                    </div>
                </div>
            </nav>
        `;
        
        // Initialize mobile menu toggle
        const mobileMenuButton = this.shadowRoot.getElementById('mobileMenuButton');
        const mobileMenu = this.shadowRoot.getElementById('mobileMenu');
        
        mobileMenuButton.addEventListener('click', () => {
            mobileMenu.classList.toggle('hidden');
            const icon = mobileMenuButton.querySelector('i');
            if (mobileMenu.classList.contains('hidden')) {
                icon.setAttribute('data-feather', 'menu');
            } else {
                icon.setAttribute('data-feather', 'x');
            }
            feather.replace();
        });
    }
}

customElements.define('custom-navbar', CustomNavbar);