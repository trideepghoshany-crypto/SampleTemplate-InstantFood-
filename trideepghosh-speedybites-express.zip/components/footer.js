class CustomFooter extends HTMLElement {
    connectedCallback() {
        this.attachShadow({ mode: 'open' });
        this.shadowRoot.innerHTML = `
            <style>
                footer {
                    background-color: #111827;
                }
                .footer-link:hover {
                    color: #6366f1;
                }
            </style>
            <footer class="py-12">
                <div class="container mx-auto px-4">
                    <div class="grid grid-cols-1 md:grid-cols-4 gap-8">
                        <div>
                            <h3 class="text-xl font-bold mb-4 flex items-center">
                                <i data-feather="zap" class="text-primary-500 w-6 h-6 mr-2"></i>
                                SpeedyBites
                            </h3>
                            <p class="text-gray-400 mb-4">Delivering happiness to your doorstep in minutes.</p>
                            <div class="flex space-x-4">
                                <a href="#" class="text-gray-400 hover:text-primary-500 transition">
                                    <i data-feather="facebook" class="w-5 h-5"></i>
                                </a>
                                <a href="#" class="text-gray-400 hover:text-primary-500 transition">
                                    <i data-feather="twitter" class="w-5 h-5"></i>
                                </a>
                                <a href="#" class="text-gray-400 hover:text-primary-500 transition">
                                    <i data-feather="instagram" class="w-5 h-5"></i>
                                </a>
                            </div>
                        </div>
                        <div>
                            <h4 class="font-semibold text-lg mb-4">Company</h4>
                            <ul class="space-y-2">
                                <li><a href="#" class="footer-link text-gray-400 transition">About Us</a></li>
                                <li><a href="#" class="footer-link text-gray-400 transition">Careers</a></li>
                                <li><a href="#" class="footer-link text-gray-400 transition">Blog</a></li>
                                <li><a href="#" class="footer-link text-gray-400 transition">Press</a></li>
                            </ul>
                        </div>
                        <div>
                            <h4 class="font-semibold text-lg mb-4">Support</h4>
                            <ul class="space-y-2">
                                <li><a href="#" class="footer-link text-gray-400 transition">Help Center</a></li>
                                <li><a href="#" class="footer-link text-gray-400 transition">Contact Us</a></li>
                                <li><a href="#" class="footer-link text-gray-400 transition">Privacy Policy</a></li>
                                <li><a href="#" class="footer-link text-gray-400 transition">Terms of Service</a></li>
                            </ul>
                        </div>
                        <div>
                            <h4 class="font-semibold text-lg mb-4">Get the App</h4>
                            <div class="space-y-4">
                                <a href="#" class="inline-flex items-center bg-gray-800 hover:bg-gray-700 px-4 py-2 rounded-lg transition">
                                    <i data-feather="download" class="w-5 h-5 mr-2"></i>
                                    <span>App Store</span>
                                </a>
                                <a href="#" class="inline-flex items-center bg-gray-800 hover:bg-gray-700 px-4 py-2 rounded-lg transition">
                                    <i data-feather="download" class="w-5 h-5 mr-2"></i>
                                    <span>Google Play</span>
                                </a>
                            </div>
                        </div>
                    </div>
                    <div class="border-t border-gray-800 mt-12 pt-8 text-center text-gray-400">
                        <p>&copy; ${new Date().getFullYear()} SpeedyBites Express. All rights reserved.</p>
                    </div>
                </div>
            </footer>
        `;
    }
}

customElements.define('custom-footer', CustomFooter);