
// Shared JavaScript functionality
document.addEventListener('DOMContentLoaded', () => {
    console.log('SpeedyBites Express is ready!');
    
    // Scroll animations
    const animateOnScroll = () => {
        const elements = document.querySelectorAll('[data-animate]');
        elements.forEach(el => {
            const elementPosition = el.getBoundingClientRect().top;
            const windowHeight = window.innerHeight;
            
            if (elementPosition < windowHeight - 100) {
                el.classList.add('animate');
            }
        });
    };

    // Initialize animations on load and scroll
    animateOnScroll();
    window.addEventListener('scroll', animateOnScroll);

    // Dark mode detection
    const setTheme = () => {
        const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
        const savedMode = localStorage.getItem('darkMode');
        
        if (savedMode !== null) {
            document.documentElement.classList.toggle('dark', savedMode === 'true');
        } else {
            document.documentElement.classList.toggle('dark', prefersDark);
        }
    };

    setTheme();

    // Watch for system theme changes
    window.matchMedia('(prefers-color-scheme: dark)').addEventListener('change', setTheme);

    // Add theme toggle button to navbar
    const addThemeToggle = () => {
        const navbars = document.querySelectorAll('custom-navbar');
        navbars.forEach(navbar => {
            const shadowRoot = navbar.shadowRoot;
            const navContainer = shadowRoot.querySelector('.container');
            
            if (!shadowRoot.getElementById('themeToggle')) {
                const toggleBtn = document.createElement('button');
                toggleBtn.id = 'themeToggle';
                toggleBtn.className = 'flex items-center justify-center w-8 h-8 rounded-full bg-gray-200 dark:bg-gray-700 ml-4';
                toggleBtn.innerHTML = '<i data-feather="sun" class="w-4 h-4 text-gray-800 dark:text-gray-200"></i>';
                
                toggleBtn.addEventListener('click', () => {
                    const isDark = document.documentElement.classList.toggle('dark');
                    localStorage.setItem('darkMode', isDark);
                    const icon = toggleBtn.querySelector('i');
                    icon.setAttribute('data-feather', isDark ? 'moon' : 'sun');
                    feather.replace();
                });

                const mobileMenu = shadowRoot.getElementById('mobileMenu');
                if (mobileMenu) {
                    const mobileToggle = toggleBtn.cloneNode(true);
                    mobileToggle.className = 'flex items-center justify-center w-8 h-8 rounded-full bg-gray-200 dark:bg-gray-700 mt-2';
                    mobileMenu.appendChild(mobileToggle);
                }

                navContainer.appendChild(toggleBtn);
                feather.replace();
            }
        });
    };

    // Wait for navbar to be loaded
    setTimeout(addThemeToggle, 100);
});
